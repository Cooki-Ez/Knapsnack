package com.company;

public class Result {
    long Value;
    long Name;

    public Result(long Name, long Value)
    {
        this.Name = Name;
        this.Value = Value;
    }
}
